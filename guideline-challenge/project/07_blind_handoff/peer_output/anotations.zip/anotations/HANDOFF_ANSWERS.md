# Blind handoff — Phản hồi của peer annotator

**Guideline:** Traffic light state & relevance v2
**Export:** `anotations.zip` (CVAT for images 1.1, Shape mode)
**Thời gian gắn nhãn:** ~12 phút 
## Tóm tắt export

| Ảnh | Số box | Ghi chú |
|---|---|---|
| BDD18 | 4 | 2 đèn xanh xa (`ego_lane`), đèn người đi bộ tách thành 2 box (bàn tay đỏ + số đếm ngược) |
| BDD26 | 1 | 1 đèn xanh ban đêm; box vẽ quanh quầng sáng vì không thấy vỏ |
| LISA20 / 25 / 28 | 5 mỗi ảnh | Mũi tên đỏ rẽ trái, 2 đèn xanh trên cần vươn, 2 đèn xanh ở cột xa |
| **Tổng** | **20** | 0 giá trị `__undefined__` · 0 `needs_review = true` · 0 tag `image_escalate` |

---

## 1. Rule nào rõ nhất / giúp quyết định nhanh nhất?

- **Mỗi hộp đèn là 1 box, không gom cụm (§2, §10.2).** Rule này không cần suy nghĩ. Trên cần vươn của LISA mình vẽ 3 box riêng ngay, và vị trí box khớp nhau giữa 3 frame (lệch ≤ 3 px).
- **Rule v2 "đầu đèn cạnh biển rẽ/quay đầu trái là `cross_traffic`" (§4).** Ở LISA20/25/28, đầu đèn mũi tên đỏ nằm ngay cạnh biển U-turn. Mình gán `red / cross_traffic / left` trong vài giây và giống hệt nhau ở cả 3 frame. Đây là rule duy nhất có mốc thị giác cụ thể (tấm biển) chứ không dựa vào suy luận về làn.
- **Loại trừ ảnh phản chiếu trên kính / nắp ca-pô (§1).** Ở BDD26 có vệt xanh phản chiếu trên kính lái (~475, 510). Mình bỏ qua ngay vì rule viết rõ.

## 2. Rule nào mơ hồ hoặc phải tự suy diễn?

1. **`relevance = ego_lane` khi không thấy làn của xe chủ.** Ở LISA, camera đứng ngay vạch dừng, trong khung không có vạch làn dưới bánh xe. Vì vậy mẹo ở §10.1 ("nhìn xuống vạch kẻ đường dưới bánh xe") không dùng được. Mình tự suy ra rằng đèn xanh trên cần vươn là `cross_traffic` và đèn xanh ở cột xa là `ego_lane`. Ví dụ LISA04 ở §9 lại gợi ý ngược lại (đầu đèn đi thẳng trên cùng giàn là của xe chủ). Mình **không tick `needs_review`** vì §7.2 chỉ nhắc tới "vạch phân làn bị mờ", không nhắc trường hợp "vạch nằm ngoài khung hình".
2. **Đèn người đi bộ:**
   - `state` chỉ có các giá trị màu của đèn xe. Bàn tay cam/đỏ mình gán `red`. Phần số đếm ngược đang **sáng trắng** thì không có giá trị nào khớp, nên mình gán `off`, dù thực tế nó đang sáng.
   - `direction` không có giá trị nào hợp, nên mình buộc phải chọn `general`.
   - Không rõ bàn tay và số đếm ngược là 1 hộp hay 2 hộp. Mình tách làm 2 box.
3. **Vẽ vỏ khi ban đêm không thấy vỏ (§3, §6).** Guideline bảo "zoom 150–300% để tìm viền vỏ". Ở BDD26, zoom 400% vẫn chỉ thấy quầng sáng, vỏ chìm hẳn vào nền đen. Mình buộc phải vẽ quanh quầng sáng, tức là vi phạm rule No-bloom, và guideline không có hướng xử lý dự phòng.
4. **Ngưỡng 8×8 px đo trên cái gì?** Đo trên vỏ hay trên bóng đang sáng? Các đầu đèn xa ở LISA rộng khoảng 9–10 px, sát ngưỡng. Ở BDD26 vỏ không nhìn thấy nên không đo được.
5. **"Quay về phía xe" với đầu đèn xa.** Ở LISA, cạnh đầu đèn xanh xa (~812, 400) có một đầu đèn đỏ đang sáng, quay xiên. Mình không vẽ vì đoán là nó quay 90°, nhưng không có tiêu chí nào để chắc chắn.
6. **LISA04 có expected output `general`/`straight`.** Chính ví dụ mẫu cũng không chọn một giá trị duy nhất.

## 3. Sample nào khiến guideline "vỡ"?

| Sample | Vì sao vỡ | Mình đã làm gì |
|---|---|---|
| **LISA20 / 25 / 28** | Cùng một giàn đèn có 2 đầu tròn xanh, cộng thêm 2 đầu xanh ở cột xa, nhưng không thấy làn của xe chủ. Các rule về relevance (§4, §7.2, §10.1) đều cần thông tin không có trong ảnh. Đây đúng là loại lỗi mà §10.1 gọi là "Critical Failure". | Gán 2 đầu trên cần vươn là `cross_traffic` và 2 đầu ở cột xa là `ego_lane`, không tick `needs_review`. **Rất có thể sai** so với ý owner nếu dựa theo ví dụ LISA04. |
| **BDD26** | Ban đêm, vỏ đèn hoàn toàn vô hình nên hai rule "ôm vỏ, không ôm bloom" và "8×8 px trên vỏ" đều không thực hiện được. Ngoài ra, đèn bàn tay đỏ cho người đi bộ (~432, 118) nằm trong scope nhưng mình **bỏ sót**, vì bị quầng xanh lấn át và không có rule nào nhắc kiểm tra đèn phụ trên cùng cột. | 1 box 39×53 px ôm quầng sáng. |
| **BDD18** | Đèn người đi bộ gồm bàn tay và số đếm ngược, nhưng taxonomy không mô tả được: thiếu trạng thái "trắng/walk/countdown", `direction` không phù hợp, và không có quy tắc tách instance cho loại đèn này. | 2 box: `red` và `off` (gán `off` là sai về mặt ngữ nghĩa). |

## 4. Attribute/default nào trong CVAT dễ gây thao tác sai?

1. **`needs_review` là checkbox mặc định `false`.** Để nguyên mặc định thì hệ thống hiểu là "tự tin". Kết quả là mình có 0/20 box được gắn cờ, dù có ít nhất 8 box đang mơ hồ (relevance ở LISA, BDD26, đèn người đi bộ ở BDD18). Cờ này chỉ có tác dụng nếu annotator chủ động nhớ bấm.
2. **`__undefined__` vẫn nằm trong danh sách chọn được.** CVAT không chặn Save khi còn `__undefined__`. Lần này mình không để sót, nhưng việc tránh lỗi hoàn toàn trông vào kỷ luật cá nhân (§10.4).
3. **Thứ tự giá trị trong `direction`.** Giá trị `general` nằm cuối danh sách, sau `straight`, trong khi thực tế phần lớn đầu đèn là `general`. Chọn nhầm `straight` rất dễ, vì guideline (ví dụ LISA04) cũng không phân biệt rõ hai giá trị này.
4. **Không có giá trị N/A cho `direction`** với đèn người đi bộ. Annotator buộc phải chọn bừa `general`, và dữ liệu bị lẫn nhiễu.
5. **`state` không có giá trị nào cho đèn trắng hoặc số đếm ngược.** Mình phải gán `off` cho một đèn đang sáng.
6. **`mutable: false` cho mọi attribute** thì ổn với Shape mode. Tuy vậy, nếu có ai dùng track (dù §8 cấm), `state` sẽ không đổi được theo từng frame.

## 5. Một thay đổi cụ thể giúp annotator mới ít hỏi hơn?

**Thêm vào §7 một "Bảng quyết định nhanh", kèm 1 ảnh LISA20 đã được owner vẽ và gán nhãn đúng.** Bảng có 3 dòng cho 3 tình huống gây vỡ ở trên:

| Tình huống | Quyết định |
|---|---|
| Không thấy làn của xe chủ, hoặc nhiều đầu tròn cùng màu trên giàn | `relevance = uncertain`, **bắt buộc** `needs_review = true` |
| Ban đêm, zoom mà không thấy viền vỏ | Vẽ quanh phần bóng đang sáng (không lấy bloom), `needs_review = true` |
| Đèn người đi bộ | 1 box cho cả hộp (bàn tay + số đếm ngược). `state`: bàn tay là `red`, người đi/đếm ngược trắng là `green`. `direction = general` |

Kèm theo đó, trong CVAT nên đổi `needs_review` từ checkbox sang select `__undefined__ / yes / no` để annotator bắt buộc phải quyết định có cần review hay không, thay vì nó mặc định là `false`.
